from fastapi import FastAPI, HTTPException
import pickle

app = FastAPI()

# Load the model
with open('models/model.pkl', 'rb') as f:
    loaded_model = pickle.load(f)

# API Endpoints
@app.get('/')
def index():
    return {'Hello': 'Welcome to IMDB prediction service, access the api docs and test the API at http://0.0.0.0/docs.'}

@app.post("/predict")
async def predict_review(review: str):
    try:
        # Make predictions using the loaded model
        prediction = loaded_model.predict([review])

        # Assuming binary classification (positive/negative sentiment)
        sentiment = "Positive" if prediction[0] == 1 else "Negative"

        return {"review": review, "sentiment": sentiment}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
"""
@app.post("/predict")
async def predict_review(review: str):
    try:
        # Make predictions using the loaded model
        prediction = loaded_model.predict([review])

        # Assuming binary classification (positive/negative sentiment)
        sentiment = "Positive" if prediction[0] == 1 else "Negative"

        # Return the review and predicted sentiment
        return {"review": review, "sentiment": sentiment}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
"""

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
