from fastapi import FastAPI, HTTPException
import pickle
import uvicorn
import onnxruntime
import numpy as np

app = FastAPI()

# Load the ONNX model/best_model.onnx
onnx_session = onnxruntime.InferenceSession("../outputs/best_model.onnx")

# Load preprocessing transformations from pickle files
with open('../outputs/vectorizer.pkl', 'rb') as vectorizer_file:
    vectorizer = pickle.load(vectorizer_file)

with open('../outputs/label_encoder.pkl', 'rb') as label_encoder_file:
    label_encoder = pickle.load(label_encoder_file)

# API Endpoints
@app.get('/')
def index():
    return {'Hello': 'Welcome to IMDB prediction service, access the api docs and test the API at http://127.0.0.1:8000/docs.'}

@app.post("/predict")
async def predict_review(review: str):
    try:
        # Vectorize the processed review
        review_vectorized = vectorizer.transform([review])
        review_dense = review_vectorized.toarray()

        # Reshape the input to match the expected shape
        review_dense = review_dense.reshape(1, -1)

        # Make predictions using the ONNX model
        input_name = onnx_session.get_inputs()[0].name
        output_name = onnx_session.get_outputs()[0].name
        onnx_input = {input_name: review_dense.astype(np.float32)}
        prediction = onnx_session.run([output_name], onnx_input)[0]

        # Convert the prediction to the original label
        sentiment = "Positive" if label_encoder.inverse_transform([np.argmax(prediction)]) == 1 else "Negative"

        return {"review": review, "sentiment": sentiment}

    except Exception as e:
        print(f"Exception during prediction: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

"""
@app.post("/predict")
async def predict_review(review: str):
    try:
        # Vectorize the processed review
        review_vectorized = vectorizer.transform([review])
        review_dense = review_vectorized.toarray()

        # Reshape the input to match the expected shape
        review_dense = review_dense.reshape(1, -1)

        # Make predictions using the ONNX model
        input_name = onnx_session.get_inputs()[0].name
        output_name = onnx_session.get_outputs()[0].name
        onnx_input = {input_name: review_dense.astype(np.float32)}
        prediction = onnx_session.run([output_name], onnx_input)[0]


        # Convert the prediction to the original label
        sentiment = "Positive" if label_encoder.inverse_transform([np.argmax(prediction)]) == 1 else "Negative"

        return {"review": review, "sentiment": sentiment}

    except Exception as e:
        print(f"Exception during prediction: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
"""

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)